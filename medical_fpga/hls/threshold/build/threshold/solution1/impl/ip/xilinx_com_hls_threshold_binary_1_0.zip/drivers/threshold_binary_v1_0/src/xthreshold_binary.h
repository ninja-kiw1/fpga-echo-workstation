// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XTHRESHOLD_BINARY_H
#define XTHRESHOLD_BINARY_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xthreshold_binary_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XThreshold_binary_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XThreshold_binary;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XThreshold_binary_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XThreshold_binary_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XThreshold_binary_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XThreshold_binary_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XThreshold_binary_Initialize(XThreshold_binary *InstancePtr, u16 DeviceId);
XThreshold_binary_Config* XThreshold_binary_LookupConfig(u16 DeviceId);
int XThreshold_binary_CfgInitialize(XThreshold_binary *InstancePtr, XThreshold_binary_Config *ConfigPtr);
#else
int XThreshold_binary_Initialize(XThreshold_binary *InstancePtr, const char* InstanceName);
int XThreshold_binary_Release(XThreshold_binary *InstancePtr);
#endif

void XThreshold_binary_Start(XThreshold_binary *InstancePtr);
u32 XThreshold_binary_IsDone(XThreshold_binary *InstancePtr);
u32 XThreshold_binary_IsIdle(XThreshold_binary *InstancePtr);
u32 XThreshold_binary_IsReady(XThreshold_binary *InstancePtr);
void XThreshold_binary_EnableAutoRestart(XThreshold_binary *InstancePtr);
void XThreshold_binary_DisableAutoRestart(XThreshold_binary *InstancePtr);

void XThreshold_binary_Set_input_r(XThreshold_binary *InstancePtr, u64 Data);
u64 XThreshold_binary_Get_input_r(XThreshold_binary *InstancePtr);
void XThreshold_binary_Set_output_r(XThreshold_binary *InstancePtr, u64 Data);
u64 XThreshold_binary_Get_output_r(XThreshold_binary *InstancePtr);
void XThreshold_binary_Set_width(XThreshold_binary *InstancePtr, u32 Data);
u32 XThreshold_binary_Get_width(XThreshold_binary *InstancePtr);
void XThreshold_binary_Set_height(XThreshold_binary *InstancePtr, u32 Data);
u32 XThreshold_binary_Get_height(XThreshold_binary *InstancePtr);
void XThreshold_binary_Set_threshold_value(XThreshold_binary *InstancePtr, u32 Data);
u32 XThreshold_binary_Get_threshold_value(XThreshold_binary *InstancePtr);

void XThreshold_binary_InterruptGlobalEnable(XThreshold_binary *InstancePtr);
void XThreshold_binary_InterruptGlobalDisable(XThreshold_binary *InstancePtr);
void XThreshold_binary_InterruptEnable(XThreshold_binary *InstancePtr, u32 Mask);
void XThreshold_binary_InterruptDisable(XThreshold_binary *InstancePtr, u32 Mask);
void XThreshold_binary_InterruptClear(XThreshold_binary *InstancePtr, u32 Mask);
u32 XThreshold_binary_InterruptGetEnabled(XThreshold_binary *InstancePtr);
u32 XThreshold_binary_InterruptGetStatus(XThreshold_binary *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
