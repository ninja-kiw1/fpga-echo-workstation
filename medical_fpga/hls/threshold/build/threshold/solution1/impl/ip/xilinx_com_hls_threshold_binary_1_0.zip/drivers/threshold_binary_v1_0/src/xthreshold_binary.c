// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xthreshold_binary.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XThreshold_binary_CfgInitialize(XThreshold_binary *InstancePtr, XThreshold_binary_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XThreshold_binary_Start(XThreshold_binary *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_AP_CTRL) & 0x80;
    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XThreshold_binary_IsDone(XThreshold_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XThreshold_binary_IsIdle(XThreshold_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XThreshold_binary_IsReady(XThreshold_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XThreshold_binary_EnableAutoRestart(XThreshold_binary *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XThreshold_binary_DisableAutoRestart(XThreshold_binary *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_AP_CTRL, 0);
}

void XThreshold_binary_Set_input_r(XThreshold_binary *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_INPUT_R_DATA, (u32)(Data));
    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_INPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XThreshold_binary_Get_input_r(XThreshold_binary *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_INPUT_R_DATA);
    Data += (u64)XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_INPUT_R_DATA + 4) << 32;
    return Data;
}

void XThreshold_binary_Set_output_r(XThreshold_binary *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_OUTPUT_R_DATA, (u32)(Data));
    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_OUTPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XThreshold_binary_Get_output_r(XThreshold_binary *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_OUTPUT_R_DATA);
    Data += (u64)XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_OUTPUT_R_DATA + 4) << 32;
    return Data;
}

void XThreshold_binary_Set_width(XThreshold_binary *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XThreshold_binary_Get_width(XThreshold_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XThreshold_binary_Set_height(XThreshold_binary *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_HEIGHT_DATA, Data);
}

u32 XThreshold_binary_Get_height(XThreshold_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_HEIGHT_DATA);
    return Data;
}

void XThreshold_binary_Set_threshold_value(XThreshold_binary *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_THRESHOLD_VALUE_DATA, Data);
}

u32 XThreshold_binary_Get_threshold_value(XThreshold_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_THRESHOLD_VALUE_DATA);
    return Data;
}

void XThreshold_binary_InterruptGlobalEnable(XThreshold_binary *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_GIE, 1);
}

void XThreshold_binary_InterruptGlobalDisable(XThreshold_binary *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_GIE, 0);
}

void XThreshold_binary_InterruptEnable(XThreshold_binary *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_IER);
    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_IER, Register | Mask);
}

void XThreshold_binary_InterruptDisable(XThreshold_binary *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_IER);
    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_IER, Register & (~Mask));
}

void XThreshold_binary_InterruptClear(XThreshold_binary *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XThreshold_binary_WriteReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_ISR, Mask);
}

u32 XThreshold_binary_InterruptGetEnabled(XThreshold_binary *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_IER);
}

u32 XThreshold_binary_InterruptGetStatus(XThreshold_binary *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XThreshold_binary_ReadReg(InstancePtr->Control_BaseAddress, XTHRESHOLD_BINARY_CONTROL_ADDR_ISR);
}

