// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xthreshold_binary.h"

extern XThreshold_binary_Config XThreshold_binary_ConfigTable[];

XThreshold_binary_Config *XThreshold_binary_LookupConfig(u16 DeviceId) {
	XThreshold_binary_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XTHRESHOLD_BINARY_NUM_INSTANCES; Index++) {
		if (XThreshold_binary_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XThreshold_binary_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XThreshold_binary_Initialize(XThreshold_binary *InstancePtr, u16 DeviceId) {
	XThreshold_binary_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XThreshold_binary_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XThreshold_binary_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

