// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XMEAN_FILTER_H
#define XMEAN_FILTER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmean_filter_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XMean_filter_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XMean_filter;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMean_filter_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMean_filter_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMean_filter_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMean_filter_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XMean_filter_Initialize(XMean_filter *InstancePtr, u16 DeviceId);
XMean_filter_Config* XMean_filter_LookupConfig(u16 DeviceId);
int XMean_filter_CfgInitialize(XMean_filter *InstancePtr, XMean_filter_Config *ConfigPtr);
#else
int XMean_filter_Initialize(XMean_filter *InstancePtr, const char* InstanceName);
int XMean_filter_Release(XMean_filter *InstancePtr);
#endif

void XMean_filter_Start(XMean_filter *InstancePtr);
u32 XMean_filter_IsDone(XMean_filter *InstancePtr);
u32 XMean_filter_IsIdle(XMean_filter *InstancePtr);
u32 XMean_filter_IsReady(XMean_filter *InstancePtr);
void XMean_filter_EnableAutoRestart(XMean_filter *InstancePtr);
void XMean_filter_DisableAutoRestart(XMean_filter *InstancePtr);

void XMean_filter_Set_input_r(XMean_filter *InstancePtr, u64 Data);
u64 XMean_filter_Get_input_r(XMean_filter *InstancePtr);
void XMean_filter_Set_output_r(XMean_filter *InstancePtr, u64 Data);
u64 XMean_filter_Get_output_r(XMean_filter *InstancePtr);
void XMean_filter_Set_width(XMean_filter *InstancePtr, u32 Data);
u32 XMean_filter_Get_width(XMean_filter *InstancePtr);
void XMean_filter_Set_height(XMean_filter *InstancePtr, u32 Data);
u32 XMean_filter_Get_height(XMean_filter *InstancePtr);

void XMean_filter_InterruptGlobalEnable(XMean_filter *InstancePtr);
void XMean_filter_InterruptGlobalDisable(XMean_filter *InstancePtr);
void XMean_filter_InterruptEnable(XMean_filter *InstancePtr, u32 Mask);
void XMean_filter_InterruptDisable(XMean_filter *InstancePtr, u32 Mask);
void XMean_filter_InterruptClear(XMean_filter *InstancePtr, u32 Mask);
u32 XMean_filter_InterruptGetEnabled(XMean_filter *InstancePtr);
u32 XMean_filter_InterruptGetStatus(XMean_filter *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
