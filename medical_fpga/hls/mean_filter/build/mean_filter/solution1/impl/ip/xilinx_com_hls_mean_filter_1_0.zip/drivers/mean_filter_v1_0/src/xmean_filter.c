// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmean_filter.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMean_filter_CfgInitialize(XMean_filter *InstancePtr, XMean_filter_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMean_filter_Start(XMean_filter *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMean_filter_IsDone(XMean_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMean_filter_IsIdle(XMean_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMean_filter_IsReady(XMean_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMean_filter_EnableAutoRestart(XMean_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMean_filter_DisableAutoRestart(XMean_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_AP_CTRL, 0);
}

void XMean_filter_Set_input_r(XMean_filter *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_INPUT_R_DATA, (u32)(Data));
    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_INPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMean_filter_Get_input_r(XMean_filter *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_INPUT_R_DATA);
    Data += (u64)XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_INPUT_R_DATA + 4) << 32;
    return Data;
}

void XMean_filter_Set_output_r(XMean_filter *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_OUTPUT_R_DATA, (u32)(Data));
    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_OUTPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMean_filter_Get_output_r(XMean_filter *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_OUTPUT_R_DATA);
    Data += (u64)XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_OUTPUT_R_DATA + 4) << 32;
    return Data;
}

void XMean_filter_Set_width(XMean_filter *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XMean_filter_Get_width(XMean_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XMean_filter_Set_height(XMean_filter *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_HEIGHT_DATA, Data);
}

u32 XMean_filter_Get_height(XMean_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_HEIGHT_DATA);
    return Data;
}

void XMean_filter_InterruptGlobalEnable(XMean_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_GIE, 1);
}

void XMean_filter_InterruptGlobalDisable(XMean_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_GIE, 0);
}

void XMean_filter_InterruptEnable(XMean_filter *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_IER);
    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_IER, Register | Mask);
}

void XMean_filter_InterruptDisable(XMean_filter *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_IER);
    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMean_filter_InterruptClear(XMean_filter *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMean_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_ISR, Mask);
}

u32 XMean_filter_InterruptGetEnabled(XMean_filter *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_IER);
}

u32 XMean_filter_InterruptGetStatus(XMean_filter *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMean_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEAN_FILTER_CONTROL_ADDR_ISR);
}

