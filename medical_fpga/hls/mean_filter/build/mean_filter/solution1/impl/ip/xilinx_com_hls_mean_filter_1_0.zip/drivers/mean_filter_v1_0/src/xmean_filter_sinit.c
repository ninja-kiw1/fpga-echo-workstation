// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xmean_filter.h"

extern XMean_filter_Config XMean_filter_ConfigTable[];

XMean_filter_Config *XMean_filter_LookupConfig(u16 DeviceId) {
	XMean_filter_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMEAN_FILTER_NUM_INSTANCES; Index++) {
		if (XMean_filter_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMean_filter_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMean_filter_Initialize(XMean_filter *InstancePtr, u16 DeviceId) {
	XMean_filter_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMean_filter_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMean_filter_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

