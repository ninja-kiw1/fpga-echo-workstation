// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xmorphology_binary.h"

extern XMorphology_binary_Config XMorphology_binary_ConfigTable[];

XMorphology_binary_Config *XMorphology_binary_LookupConfig(u16 DeviceId) {
	XMorphology_binary_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMORPHOLOGY_BINARY_NUM_INSTANCES; Index++) {
		if (XMorphology_binary_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMorphology_binary_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMorphology_binary_Initialize(XMorphology_binary *InstancePtr, u16 DeviceId) {
	XMorphology_binary_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMorphology_binary_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMorphology_binary_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

