// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XMORPHOLOGY_BINARY_H
#define XMORPHOLOGY_BINARY_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmorphology_binary_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XMorphology_binary_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XMorphology_binary;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMorphology_binary_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMorphology_binary_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMorphology_binary_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMorphology_binary_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XMorphology_binary_Initialize(XMorphology_binary *InstancePtr, u16 DeviceId);
XMorphology_binary_Config* XMorphology_binary_LookupConfig(u16 DeviceId);
int XMorphology_binary_CfgInitialize(XMorphology_binary *InstancePtr, XMorphology_binary_Config *ConfigPtr);
#else
int XMorphology_binary_Initialize(XMorphology_binary *InstancePtr, const char* InstanceName);
int XMorphology_binary_Release(XMorphology_binary *InstancePtr);
#endif

void XMorphology_binary_Start(XMorphology_binary *InstancePtr);
u32 XMorphology_binary_IsDone(XMorphology_binary *InstancePtr);
u32 XMorphology_binary_IsIdle(XMorphology_binary *InstancePtr);
u32 XMorphology_binary_IsReady(XMorphology_binary *InstancePtr);
void XMorphology_binary_EnableAutoRestart(XMorphology_binary *InstancePtr);
void XMorphology_binary_DisableAutoRestart(XMorphology_binary *InstancePtr);

void XMorphology_binary_Set_input_r(XMorphology_binary *InstancePtr, u64 Data);
u64 XMorphology_binary_Get_input_r(XMorphology_binary *InstancePtr);
void XMorphology_binary_Set_output_r(XMorphology_binary *InstancePtr, u64 Data);
u64 XMorphology_binary_Get_output_r(XMorphology_binary *InstancePtr);
void XMorphology_binary_Set_width(XMorphology_binary *InstancePtr, u32 Data);
u32 XMorphology_binary_Get_width(XMorphology_binary *InstancePtr);
void XMorphology_binary_Set_height(XMorphology_binary *InstancePtr, u32 Data);
u32 XMorphology_binary_Get_height(XMorphology_binary *InstancePtr);
void XMorphology_binary_Set_mode(XMorphology_binary *InstancePtr, u32 Data);
u32 XMorphology_binary_Get_mode(XMorphology_binary *InstancePtr);

void XMorphology_binary_InterruptGlobalEnable(XMorphology_binary *InstancePtr);
void XMorphology_binary_InterruptGlobalDisable(XMorphology_binary *InstancePtr);
void XMorphology_binary_InterruptEnable(XMorphology_binary *InstancePtr, u32 Mask);
void XMorphology_binary_InterruptDisable(XMorphology_binary *InstancePtr, u32 Mask);
void XMorphology_binary_InterruptClear(XMorphology_binary *InstancePtr, u32 Mask);
u32 XMorphology_binary_InterruptGetEnabled(XMorphology_binary *InstancePtr);
u32 XMorphology_binary_InterruptGetStatus(XMorphology_binary *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
