// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmorphology_binary.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMorphology_binary_CfgInitialize(XMorphology_binary *InstancePtr, XMorphology_binary_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMorphology_binary_Start(XMorphology_binary *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMorphology_binary_IsDone(XMorphology_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMorphology_binary_IsIdle(XMorphology_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMorphology_binary_IsReady(XMorphology_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMorphology_binary_EnableAutoRestart(XMorphology_binary *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMorphology_binary_DisableAutoRestart(XMorphology_binary *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_AP_CTRL, 0);
}

void XMorphology_binary_Set_input_r(XMorphology_binary *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_INPUT_R_DATA, (u32)(Data));
    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_INPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMorphology_binary_Get_input_r(XMorphology_binary *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_INPUT_R_DATA);
    Data += (u64)XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_INPUT_R_DATA + 4) << 32;
    return Data;
}

void XMorphology_binary_Set_output_r(XMorphology_binary *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_OUTPUT_R_DATA, (u32)(Data));
    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_OUTPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMorphology_binary_Get_output_r(XMorphology_binary *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_OUTPUT_R_DATA);
    Data += (u64)XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_OUTPUT_R_DATA + 4) << 32;
    return Data;
}

void XMorphology_binary_Set_width(XMorphology_binary *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XMorphology_binary_Get_width(XMorphology_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XMorphology_binary_Set_height(XMorphology_binary *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_HEIGHT_DATA, Data);
}

u32 XMorphology_binary_Get_height(XMorphology_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_HEIGHT_DATA);
    return Data;
}

void XMorphology_binary_Set_mode(XMorphology_binary *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_MODE_DATA, Data);
}

u32 XMorphology_binary_Get_mode(XMorphology_binary *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_MODE_DATA);
    return Data;
}

void XMorphology_binary_InterruptGlobalEnable(XMorphology_binary *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_GIE, 1);
}

void XMorphology_binary_InterruptGlobalDisable(XMorphology_binary *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_GIE, 0);
}

void XMorphology_binary_InterruptEnable(XMorphology_binary *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_IER);
    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_IER, Register | Mask);
}

void XMorphology_binary_InterruptDisable(XMorphology_binary *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_IER);
    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMorphology_binary_InterruptClear(XMorphology_binary *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMorphology_binary_WriteReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_ISR, Mask);
}

u32 XMorphology_binary_InterruptGetEnabled(XMorphology_binary *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_IER);
}

u32 XMorphology_binary_InterruptGetStatus(XMorphology_binary *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMorphology_binary_ReadReg(InstancePtr->Control_BaseAddress, XMORPHOLOGY_BINARY_CONTROL_ADDR_ISR);
}

