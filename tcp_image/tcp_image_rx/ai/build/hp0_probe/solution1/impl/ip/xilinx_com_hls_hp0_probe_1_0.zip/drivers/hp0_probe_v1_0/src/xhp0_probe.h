// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XHP0_PROBE_H
#define XHP0_PROBE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xhp0_probe_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XHp0_probe_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XHp0_probe;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XHp0_probe_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XHp0_probe_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XHp0_probe_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XHp0_probe_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XHp0_probe_Initialize(XHp0_probe *InstancePtr, UINTPTR BaseAddress);
XHp0_probe_Config* XHp0_probe_LookupConfig(UINTPTR BaseAddress);
#else
int XHp0_probe_Initialize(XHp0_probe *InstancePtr, u16 DeviceId);
XHp0_probe_Config* XHp0_probe_LookupConfig(u16 DeviceId);
#endif
int XHp0_probe_CfgInitialize(XHp0_probe *InstancePtr, XHp0_probe_Config *ConfigPtr);
#else
int XHp0_probe_Initialize(XHp0_probe *InstancePtr, const char* InstanceName);
int XHp0_probe_Release(XHp0_probe *InstancePtr);
#endif

void XHp0_probe_Start(XHp0_probe *InstancePtr);
u32 XHp0_probe_IsDone(XHp0_probe *InstancePtr);
u32 XHp0_probe_IsIdle(XHp0_probe *InstancePtr);
u32 XHp0_probe_IsReady(XHp0_probe *InstancePtr);
void XHp0_probe_EnableAutoRestart(XHp0_probe *InstancePtr);
void XHp0_probe_DisableAutoRestart(XHp0_probe *InstancePtr);
u64 XHp0_probe_Get_return(XHp0_probe *InstancePtr);

void XHp0_probe_Set_src(XHp0_probe *InstancePtr, u64 Data);
u64 XHp0_probe_Get_src(XHp0_probe *InstancePtr);
void XHp0_probe_Set_dst(XHp0_probe *InstancePtr, u64 Data);
u64 XHp0_probe_Get_dst(XHp0_probe *InstancePtr);
void XHp0_probe_Set_n(XHp0_probe *InstancePtr, u32 Data);
u32 XHp0_probe_Get_n(XHp0_probe *InstancePtr);
void XHp0_probe_Set_seed(XHp0_probe *InstancePtr, u64 Data);
u64 XHp0_probe_Get_seed(XHp0_probe *InstancePtr);
u64 XHp0_probe_Get_xr(XHp0_probe *InstancePtr);
u32 XHp0_probe_Get_xr_vld(XHp0_probe *InstancePtr);

void XHp0_probe_InterruptGlobalEnable(XHp0_probe *InstancePtr);
void XHp0_probe_InterruptGlobalDisable(XHp0_probe *InstancePtr);
void XHp0_probe_InterruptEnable(XHp0_probe *InstancePtr, u32 Mask);
void XHp0_probe_InterruptDisable(XHp0_probe *InstancePtr, u32 Mask);
void XHp0_probe_InterruptClear(XHp0_probe *InstancePtr, u32 Mask);
u32 XHp0_probe_InterruptGetEnabled(XHp0_probe *InstancePtr);
u32 XHp0_probe_InterruptGetStatus(XHp0_probe *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
