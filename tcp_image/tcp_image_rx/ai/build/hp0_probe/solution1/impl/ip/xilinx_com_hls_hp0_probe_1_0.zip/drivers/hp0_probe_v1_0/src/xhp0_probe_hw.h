// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of ap_return
//        bit 31~0 - ap_return[31:0] (Read)
// 0x14 : Data signal of ap_return
//        bit 31~0 - ap_return[63:32] (Read)
// 0x1c : Data signal of src
//        bit 31~0 - src[31:0] (Read/Write)
// 0x20 : Data signal of src
//        bit 31~0 - src[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of dst
//        bit 31~0 - dst[31:0] (Read/Write)
// 0x2c : Data signal of dst
//        bit 31~0 - dst[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of n
//        bit 31~0 - n[31:0] (Read/Write)
// 0x38 : reserved
// 0x3c : Data signal of seed
//        bit 31~0 - seed[31:0] (Read/Write)
// 0x40 : Data signal of seed
//        bit 31~0 - seed[63:32] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of xr
//        bit 31~0 - xr[31:0] (Read)
// 0x4c : Data signal of xr
//        bit 31~0 - xr[63:32] (Read)
// 0x50 : Control signal of xr
//        bit 0  - xr_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XHP0_PROBE_CONTROL_ADDR_AP_CTRL   0x00
#define XHP0_PROBE_CONTROL_ADDR_GIE       0x04
#define XHP0_PROBE_CONTROL_ADDR_IER       0x08
#define XHP0_PROBE_CONTROL_ADDR_ISR       0x0c
#define XHP0_PROBE_CONTROL_ADDR_AP_RETURN 0x10
#define XHP0_PROBE_CONTROL_BITS_AP_RETURN 64
#define XHP0_PROBE_CONTROL_ADDR_SRC_DATA  0x1c
#define XHP0_PROBE_CONTROL_BITS_SRC_DATA  64
#define XHP0_PROBE_CONTROL_ADDR_DST_DATA  0x28
#define XHP0_PROBE_CONTROL_BITS_DST_DATA  64
#define XHP0_PROBE_CONTROL_ADDR_N_DATA    0x34
#define XHP0_PROBE_CONTROL_BITS_N_DATA    32
#define XHP0_PROBE_CONTROL_ADDR_SEED_DATA 0x3c
#define XHP0_PROBE_CONTROL_BITS_SEED_DATA 64
#define XHP0_PROBE_CONTROL_ADDR_XR_DATA   0x48
#define XHP0_PROBE_CONTROL_BITS_XR_DATA   64
#define XHP0_PROBE_CONTROL_ADDR_XR_CTRL   0x50

