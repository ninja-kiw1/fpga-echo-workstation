// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xhp0_probe.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XHp0_probe_CfgInitialize(XHp0_probe *InstancePtr, XHp0_probe_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XHp0_probe_Start(XHp0_probe *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XHp0_probe_IsDone(XHp0_probe *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XHp0_probe_IsIdle(XHp0_probe *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XHp0_probe_IsReady(XHp0_probe *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XHp0_probe_EnableAutoRestart(XHp0_probe *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XHp0_probe_DisableAutoRestart(XHp0_probe *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_AP_CTRL, 0);
}

u64 XHp0_probe_Get_return(XHp0_probe *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_AP_RETURN);
    Data += (u64)XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_AP_RETURN + 4) << 32;
    return Data;
}
void XHp0_probe_Set_src(XHp0_probe *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_SRC_DATA, (u32)(Data));
    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_SRC_DATA + 4, (u32)(Data >> 32));
}

u64 XHp0_probe_Get_src(XHp0_probe *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_SRC_DATA);
    Data += (u64)XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_SRC_DATA + 4) << 32;
    return Data;
}

void XHp0_probe_Set_dst(XHp0_probe *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_DST_DATA, (u32)(Data));
    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_DST_DATA + 4, (u32)(Data >> 32));
}

u64 XHp0_probe_Get_dst(XHp0_probe *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_DST_DATA);
    Data += (u64)XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_DST_DATA + 4) << 32;
    return Data;
}

void XHp0_probe_Set_n(XHp0_probe *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_N_DATA, Data);
}

u32 XHp0_probe_Get_n(XHp0_probe *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_N_DATA);
    return Data;
}

void XHp0_probe_Set_seed(XHp0_probe *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_SEED_DATA, (u32)(Data));
    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_SEED_DATA + 4, (u32)(Data >> 32));
}

u64 XHp0_probe_Get_seed(XHp0_probe *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_SEED_DATA);
    Data += (u64)XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_SEED_DATA + 4) << 32;
    return Data;
}

u64 XHp0_probe_Get_xr(XHp0_probe *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_XR_DATA);
    Data += (u64)XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_XR_DATA + 4) << 32;
    return Data;
}

u32 XHp0_probe_Get_xr_vld(XHp0_probe *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_XR_CTRL);
    return Data & 0x1;
}

void XHp0_probe_InterruptGlobalEnable(XHp0_probe *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_GIE, 1);
}

void XHp0_probe_InterruptGlobalDisable(XHp0_probe *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_GIE, 0);
}

void XHp0_probe_InterruptEnable(XHp0_probe *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_IER);
    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_IER, Register | Mask);
}

void XHp0_probe_InterruptDisable(XHp0_probe *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_IER);
    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XHp0_probe_InterruptClear(XHp0_probe *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHp0_probe_WriteReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_ISR, Mask);
}

u32 XHp0_probe_InterruptGetEnabled(XHp0_probe *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_IER);
}

u32 XHp0_probe_InterruptGetStatus(XHp0_probe *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHp0_probe_ReadReg(InstancePtr->Control_BaseAddress, XHP0_PROBE_CONTROL_ADDR_ISR);
}

