// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xhp0_probe.h"

extern XHp0_probe_Config XHp0_probe_ConfigTable[];

#ifdef SDT
XHp0_probe_Config *XHp0_probe_LookupConfig(UINTPTR BaseAddress) {
	XHp0_probe_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XHp0_probe_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XHp0_probe_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XHp0_probe_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHp0_probe_Initialize(XHp0_probe *InstancePtr, UINTPTR BaseAddress) {
	XHp0_probe_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHp0_probe_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHp0_probe_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XHp0_probe_Config *XHp0_probe_LookupConfig(u16 DeviceId) {
	XHp0_probe_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XHP0_PROBE_NUM_INSTANCES; Index++) {
		if (XHp0_probe_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XHp0_probe_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHp0_probe_Initialize(XHp0_probe *InstancePtr, u16 DeviceId) {
	XHp0_probe_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHp0_probe_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHp0_probe_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

