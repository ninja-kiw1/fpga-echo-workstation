// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xvis_layer.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XVis_layer_CfgInitialize(XVis_layer *InstancePtr, XVis_layer_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XVis_layer_Start(XVis_layer *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVis_layer_ReadReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XVis_layer_WriteReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XVis_layer_IsDone(XVis_layer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVis_layer_ReadReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XVis_layer_IsIdle(XVis_layer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVis_layer_ReadReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XVis_layer_IsReady(XVis_layer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVis_layer_ReadReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XVis_layer_EnableAutoRestart(XVis_layer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVis_layer_WriteReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XVis_layer_DisableAutoRestart(XVis_layer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVis_layer_WriteReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XVis_layer_Get_return(XVis_layer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVis_layer_ReadReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XVis_layer_Set_mem(XVis_layer *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVis_layer_WriteReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_MEM_DATA, Data);
}

u32 XVis_layer_Get_mem(XVis_layer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVis_layer_ReadReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_MEM_DATA);
    return Data;
}

void XVis_layer_Set_desc(XVis_layer *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVis_layer_WriteReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_DESC_DATA, Data);
}

u32 XVis_layer_Get_desc(XVis_layer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XVis_layer_ReadReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_DESC_DATA);
    return Data;
}

void XVis_layer_InterruptGlobalEnable(XVis_layer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVis_layer_WriteReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_GIE, 1);
}

void XVis_layer_InterruptGlobalDisable(XVis_layer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVis_layer_WriteReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_GIE, 0);
}

void XVis_layer_InterruptEnable(XVis_layer *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XVis_layer_ReadReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_IER);
    XVis_layer_WriteReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_IER, Register | Mask);
}

void XVis_layer_InterruptDisable(XVis_layer *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XVis_layer_ReadReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_IER);
    XVis_layer_WriteReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XVis_layer_InterruptClear(XVis_layer *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XVis_layer_WriteReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_ISR, Mask);
}

u32 XVis_layer_InterruptGetEnabled(XVis_layer *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XVis_layer_ReadReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_IER);
}

u32 XVis_layer_InterruptGetStatus(XVis_layer *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XVis_layer_ReadReg(InstancePtr->Control_BaseAddress, XVIS_LAYER_CONTROL_ADDR_ISR);
}

