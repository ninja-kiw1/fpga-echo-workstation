// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XVIS_LAYER_H
#define XVIS_LAYER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xvis_layer_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u32 Control_BaseAddress;
} XVis_layer_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XVis_layer;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XVis_layer_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XVis_layer_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XVis_layer_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XVis_layer_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XVis_layer_Initialize(XVis_layer *InstancePtr, UINTPTR BaseAddress);
XVis_layer_Config* XVis_layer_LookupConfig(UINTPTR BaseAddress);
#else
int XVis_layer_Initialize(XVis_layer *InstancePtr, u16 DeviceId);
XVis_layer_Config* XVis_layer_LookupConfig(u16 DeviceId);
#endif
int XVis_layer_CfgInitialize(XVis_layer *InstancePtr, XVis_layer_Config *ConfigPtr);
#else
int XVis_layer_Initialize(XVis_layer *InstancePtr, const char* InstanceName);
int XVis_layer_Release(XVis_layer *InstancePtr);
#endif

void XVis_layer_Start(XVis_layer *InstancePtr);
u32 XVis_layer_IsDone(XVis_layer *InstancePtr);
u32 XVis_layer_IsIdle(XVis_layer *InstancePtr);
u32 XVis_layer_IsReady(XVis_layer *InstancePtr);
void XVis_layer_EnableAutoRestart(XVis_layer *InstancePtr);
void XVis_layer_DisableAutoRestart(XVis_layer *InstancePtr);
u32 XVis_layer_Get_return(XVis_layer *InstancePtr);

void XVis_layer_Set_mem(XVis_layer *InstancePtr, u32 Data);
u32 XVis_layer_Get_mem(XVis_layer *InstancePtr);
void XVis_layer_Set_desc(XVis_layer *InstancePtr, u32 Data);
u32 XVis_layer_Get_desc(XVis_layer *InstancePtr);

void XVis_layer_InterruptGlobalEnable(XVis_layer *InstancePtr);
void XVis_layer_InterruptGlobalDisable(XVis_layer *InstancePtr);
void XVis_layer_InterruptEnable(XVis_layer *InstancePtr, u32 Mask);
void XVis_layer_InterruptDisable(XVis_layer *InstancePtr, u32 Mask);
void XVis_layer_InterruptClear(XVis_layer *InstancePtr, u32 Mask);
u32 XVis_layer_InterruptGetEnabled(XVis_layer *InstancePtr);
u32 XVis_layer_InterruptGetStatus(XVis_layer *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
