// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xvis_layer.h"

extern XVis_layer_Config XVis_layer_ConfigTable[];

#ifdef SDT
XVis_layer_Config *XVis_layer_LookupConfig(UINTPTR BaseAddress) {
	XVis_layer_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XVis_layer_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XVis_layer_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XVis_layer_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XVis_layer_Initialize(XVis_layer *InstancePtr, UINTPTR BaseAddress) {
	XVis_layer_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XVis_layer_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XVis_layer_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XVis_layer_Config *XVis_layer_LookupConfig(u16 DeviceId) {
	XVis_layer_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XVIS_LAYER_NUM_INSTANCES; Index++) {
		if (XVis_layer_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XVis_layer_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XVis_layer_Initialize(XVis_layer *InstancePtr, u16 DeviceId) {
	XVis_layer_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XVis_layer_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XVis_layer_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

